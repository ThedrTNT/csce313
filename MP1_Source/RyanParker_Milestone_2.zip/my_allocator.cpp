/* 
 File: my_allocator.cpp
 
 Author: <your name>
 Department of Computer Science
 Texas A&M University
 Date  : <date>
 
 Modified:
 
 This file contains the implementation of the class MyAllocator.
 
 */

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include <cstdlib>
#include "my_allocator.hpp"
#include "free_list.hpp"
#include <assert.h>
#include <iostream>
#include <math.h>

/*--------------------------------------------------------------------------*/
/* NAME SPACES */ 
/*--------------------------------------------------------------------------*/

using namespace std;
/* I know, it's a bad habit, but this is a tiny program anyway... */

/*--------------------------------------------------------------------------*/
/* DATA STRUCTURES */ 
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* CONSTANTS */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* FORWARDS */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* FUNCTIONS FOR CLASS MyAllocator */
/*--------------------------------------------------------------------------*/

MyAllocator::MyAllocator(size_t _basic_block_size, size_t _size) {
    // We don't do anything yet...
    blockSize = _basic_block_size;
    remainingMem = _size;
    size_t totalSize = _basic_block_size;
    while(totalSize < _size) {
    	totalSize += _basic_block_size;
    }
    start = malloc(totalSize);

    //cout << totalSize << endl;

    SegmentHeader * head = new (start) SegmentHeader(totalSize, false, nullptr, nullptr);

    //cout << "test" << endl;

    freeList = FreeList();
    freeList.Add(head);

	//freeList.printList();
}

MyAllocator::~MyAllocator() {
    // Same here...
}

void* MyAllocator::Malloc(size_t _length) {
    cout << "MyAllocator::Malloc called with length = " << _length << endl;
    double tempLen = _length + sizeof(SegmentHeader);
    size_t len = blockSize;
    while(len < tempLen) {
    	len += blockSize;
    }

	SegmentHeader * segFree = freeList.first();
	//cout << "Freelist head length: " << segFree->length << endl;

	while(segFree != nullptr && segFree->length < len) {
		segFree = segFree->next;
	}

	if(segFree == nullptr) {
		//fail
		//cout << "No free segment found" << endl;
		return nullptr;
	}

	//cout << "Remove free segment" << endl;
	freeList.Remove(segFree);
	//freeList.printList();

	if(segFree->length > len) {
		//cout << "Splitting" << endl;
		SegmentHeader * newSegFree = segFree->split(len);
		//cout << "Adding: " << newSegFree->length << endl;
		//cout << "test: " << seg2->length + _length << endl;
		freeList.Add(newSegFree);
	}

	//freeList.printList();
	//SegmentHeader * head = freeList.first();
	//cout << "Freelist head length: " << segFree->length << endl;

    // This empty implementation just uses C standard library malloc
    return (void *)((char *)segFree + sizeof(SegmentHeader));
    //return retStart;
    //return std::malloc(_length);
}

bool MyAllocator::Free(void* _a) {
    cout << "MyAllocator::Free called" << endl;
	SegmentHeader * segFree = (SegmentHeader *) ((char *)_a - sizeof(SegmentHeader));
	freeList.Add(segFree);
    // This empty implementation just uses C standard library free
    //std::free(_a);
    return true;
}

